#!/bin/sh
# HelpLink - setup.sh
# POSIX sh: runs on Termux and any Linux (dash / ash / bash / zsh in sh mode).
# 1) asks the language  2) installs python3, OpenSSH, cloudflared  3) runs the Python wizard.

ROOT=$(cd "$(dirname "$0")" && pwd)
HL_HOME="${HELPLINK_HOME:-$HOME/.helplink}"
LANG_SEL="${HELPLINK_LANG:-}"

if ( : </dev/tty ) 2>/dev/null; then TTY=/dev/tty; else TTY=/dev/stdin; fi

say()  { printf '%s\n' "$*"; }
t()    { if [ "$LANG_SEL" = "vi" ]; then say "$1"; else say "$2"; fi; }
ask()  { printf '%s' "$1"; IFS= read -r ANS <"$TTY" || ANS=""; }
have() { command -v "$1" >/dev/null 2>&1; }
have_sshd() {
  have sshd || [ -x /usr/sbin/sshd ] || [ -x /usr/local/sbin/sshd ] || [ -x /sbin/sshd ] \
    || [ -x /usr/bin/sshd ] || [ -x /usr/lib/openssh/sshd ]
}

# ---- 1. language ---------------------------------------------------------
if [ -z "$LANG_SEL" ]; then
  say ""
  say "Choose language / Chọn ngôn ngữ:"
  say "  1) Tiếng Việt"
  say "  2) English"
  ask "1/2 [1]: "
  case "$ANS" in 2) LANG_SEL=en ;; *) LANG_SEL=vi ;; esac
fi
export HELPLINK_LANG="$LANG_SEL"

say ""
t "== HelpLink: cài đặt ==" "== HelpLink: setup =="
t "Script này sẽ: (1) kiểm tra/cài python3, OpenSSH, curl, cloudflared; (2) chạy trình hướng dẫn cài đặt; (3) thêm alias vào Bash, Zsh, Fish." \
  "This script will: (1) check/install python3, OpenSSH, curl, cloudflared; (2) run the setup wizard; (3) add the alias to Bash, Zsh and Fish."

# ---- 2. package manager ----------------------------------------------------
SUDO=""
if [ "$(id -u 2>/dev/null)" != "0" ]; then
  if have sudo; then SUDO="sudo"; elif have doas; then SUDO="doas"; fi
fi

PM=""
if [ -n "${TERMUX_VERSION:-}" ] || [ -d /data/data/com.termux/files/usr ]; then PM=pkg
elif have apt-get; then PM=apt
elif have dnf; then PM=dnf
elif have yum; then PM=yum
elif have pacman; then PM=pacman
elif have apk; then PM=apk
elif have zypper; then PM=zypper
elif have xbps-install; then PM=xbps
fi

pkgname() { # $1 = python | ssh | sshd | curl
  case "$PM:$1" in
    apt:python) echo python3 ;;            apt:ssh) echo openssh-client ;;      apt:sshd) echo openssh-server ;;
    dnf:python|yum:python) echo python3 ;; dnf:ssh|yum:ssh) echo openssh-clients ;; dnf:sshd|yum:sshd) echo openssh-server ;;
    pacman:python) echo python ;;          pacman:ssh|pacman:sshd) echo openssh ;;
    apk:python) echo python3 ;;            apk:ssh|apk:sshd) echo openssh ;;
    zypper:python) echo python3 ;;         zypper:ssh|zypper:sshd) echo openssh ;;
    xbps:python) echo python3 ;;           xbps:ssh|xbps:sshd) echo openssh ;;
    pkg:python) echo python ;;             pkg:ssh|pkg:sshd) echo openssh ;;
    *:curl) echo curl ;;
  esac
}

pm_install() {
  case "$PM" in
    pkg)    pkg install -y "$@" ;;
    apt)    $SUDO apt-get update -y >/dev/null 2>&1; $SUDO apt-get install -y "$@" ;;
    dnf)    $SUDO dnf install -y "$@" ;;
    yum)    $SUDO yum install -y "$@" ;;
    pacman) $SUDO pacman -S --noconfirm --needed "$@" ;;
    apk)    $SUDO apk add "$@" ;;
    zypper) $SUDO zypper --non-interactive install "$@" ;;
    xbps)   $SUDO xbps-install -Sy "$@" ;;
    *)      return 1 ;;
  esac
}

NEED=""
add() { n=$(pkgname "$1"); case " $NEED " in *" $n "*) ;; *) NEED="$NEED $n" ;; esac; }
have python3 || add python
{ have ssh && have ssh-keygen; } || add ssh
have_sshd || add sshd
have curl || add curl

if [ -n "$NEED" ]; then
  say ""
  t "Cần cài thêm:$NEED" "Missing packages:$NEED"
  if [ -z "$PM" ]; then
    t "[!] Không nhận ra trình quản lý gói. Hãy tự cài: python3, openssh (client + server), curl." \
      "[!] Unknown package manager. Please install python3, openssh (client + server) and curl yourself."
  else
    t "Giải thích: đây là các gói hệ thống cần cho tool (Python chạy web terminal, OpenSSH là lõi điều khiển, curl để tải cloudflared)." \
      "Why: these are system packages the tool needs (Python runs the web terminal, OpenSSH is the control core, curl downloads cloudflared)."
    if [ "$PM" != "pkg" ] && [ "$(id -u)" != "0" ] && [ -z "$SUDO" ]; then
      t "[!] Không có quyền root/sudo. Hãy cài thủ công rồi chạy lại setup.sh." \
        "[!] No root/sudo. Install them manually, then run setup.sh again."
    else
      ask "$(t 'Cài ngay bây giờ? [Y/n]: ' 'Install now? [Y/n]: ')"
      case "$ANS" in
        n|N|no|NO|không|khong) t "Bỏ qua cài đặt gói." "Skipped package install."; SKIPPED=1 ;;
        *) pm_install $NEED || t "[!] Cài gói thất bại, hãy cài thủ công." "[!] Package install failed, please install manually." ;;
      esac
      if [ -z "${SKIPPED:-}" ] && [ "$PM" != "pkg" ] && echo "$NEED" | grep -qE "openssh-server|openssh"; then
        t "[!] Lưu ý: một số distro (Debian/Ubuntu/Fedora...) tự bật dịch vụ SSH hệ thống ở cổng 22 khi cài openssh-server. HelpLink KHÔNG cần nó. Nếu không muốn, tắt bằng: sudo systemctl disable --now ssh (hoặc sshd)." \
          "[!] Note: some distros (Debian/Ubuntu/Fedora...) auto-start the system SSH service on port 22 when installing openssh-server. HelpLink does NOT need it. To turn it off: sudo systemctl disable --now ssh (or sshd)."
      fi
    fi
  fi
fi

# ---- 3. cloudflared ---------------------------------------------------------
CF="$HL_HOME/bin/cloudflared"
mkdir -p "$HL_HOME/bin"
if ! have cloudflared && [ ! -x "$CF" ]; then
  say ""
  t "Đang cài cloudflared (tạo link công khai tạm thời)..." "Installing cloudflared (creates the temporary public link)..."
  [ "$PM" = "pkg" ] && pkg install -y cloudflared
  if ! have cloudflared && [ "$PM" != "pkg" ]; then
    case "$(uname -m)" in
      x86_64|amd64) CFA=amd64 ;;
      aarch64|arm64) CFA=arm64 ;;
      armv7l|armv8l|arm) CFA=arm ;;
      i386|i686) CFA=386 ;;
      *) CFA="" ;;
    esac
    if [ -n "$CFA" ] && have curl; then
      curl -fL --progress-bar -o "$CF" "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$CFA" \
        && chmod +x "$CF" \
        || { rm -f "$CF"; t "[!] Tải cloudflared thất bại." "[!] cloudflared download failed."; }
    else
      t "[!] Không tự cài được cloudflared trên kiến trúc này. Hãy cài thủ công." "[!] Cannot auto-install cloudflared on this architecture. Install it manually."
    fi
  fi
fi

# ---- 4. python wizard -------------------------------------------------------
chmod +x "$ROOT/bin/helplink" "$ROOT/setup.sh" 2>/dev/null
PY=python3; have python3 || PY=python
if ! have "$PY"; then
  t "[x] Không có python3 nên chưa chạy được trình cài đặt." "[x] python3 is missing, cannot run the wizard."
  exit 1
fi
PYTHONPATH="$ROOT/src" "$PY" -m helplink --setup <"$TTY"
