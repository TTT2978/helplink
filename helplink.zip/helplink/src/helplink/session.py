"""The 'run' flow: consent -> ssh -> web terminal -> cloudflared -> wait."""
import getpass
import secrets
import signal
import threading
import time

from . import ui
from .sshd import SshServer
from .tunnel import Tunnel
from .webterm import WebTerm


def _explain(tr, e):
    msg = str(e)
    if msg == "ssh-client":
        return tr("r_no_ssh")
    if msg == "sshd":
        return tr("r_no_sshd")
    if msg == "cloudflared":
        return tr("r_no_cf")
    if msg.startswith("sshd-start:"):
        return tr("r_sshd_fail", err=msg.split(":", 1)[1])
    if msg.startswith("tunnel:"):
        return tr("r_tunnel_fail", err=msg.split(":", 1)[1])
    return msg


def run(cfg, tr):
    minutes = int(cfg.get("timeout_min") or 0)
    ui.say(tr("r_intro", user=getpass.getuser(),
              timeout=(tr("r_minutes", n=minutes) if minutes else tr("r_no_limit"))))
    if not ui.confirm(tr("r_consent_q"), False):
        ui.note(tr("r_aborted"))
        return 1

    token = cfg.get("token") if cfg.get("token_mode") == "fixed" and cfg.get("token") \
        else secrets.token_urlsafe(18)
    stop = threading.Event()
    signal.signal(signal.SIGINT, lambda *a: stop.set())
    signal.signal(signal.SIGTERM, lambda *a: stop.set())

    ssh = SshServer(cfg)
    web = tunnel = None
    try:
        ui.step("start ssh")
        ssh.prepare()
        ssh.start()

        def on_event(kind, info):
            if kind == "connected":
                ui.note(tr("r_connected", ip=info))
            else:
                ui.note(tr("r_disconnected"))

        web = WebTerm(token, ssh.client_cmd(), tr.web(), on_event)
        port = web.start()

        ui.step("start cloudflared tunnel")
        tunnel = Tunnel(port)
        url = tunnel.start()

        ui.step("done!")
        print("link public:")
        print("%s/?t=%s" % (url, token), flush=True)
        print()
        ui.note(tr("r_link_note"))
        ui.note(tr("r_stop_note"))

        deadline = time.time() + minutes * 60 if minutes else None
        while not stop.wait(1):
            if deadline and time.time() >= deadline:
                ui.note(tr("r_timeout_hit"))
                break
            if not tunnel.alive():
                ui.err(tr("r_tunnel_died"))
                break
            if not ssh.alive():
                ui.err(tr("r_sshd_died"))
                break
        code = 0
    except RuntimeError as e:
        ui.err(_explain(tr, e))
        code = 1
    finally:
        ui.note(tr("r_stopping"))
        if tunnel:
            tunnel.stop()
        if web:
            web.stop()
        ssh.stop()
    ui.step(tr("r_stopped"))
    return code
