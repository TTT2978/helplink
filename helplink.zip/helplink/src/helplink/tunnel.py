"""cloudflared part: a Cloudflare quick tunnel that exposes the local web terminal."""
import os
import re
import shutil
import subprocess
import threading

from .paths import BIN_DIR

URL_RE = re.compile(r"https://([a-zA-Z0-9-]+)\.trycloudflare\.com")


def find_cloudflared():
    p = shutil.which("cloudflared")
    if p:
        return p
    local = BIN_DIR / "cloudflared"
    if os.access(str(local), os.X_OK):
        return str(local)
    return None


class Tunnel:
    def __init__(self, port):
        self.port = port
        self.proc = None
        self.url = None
        self.tail = []
        self._ev = threading.Event()

    def start(self, timeout=60):
        exe = find_cloudflared()
        if not exe:
            raise RuntimeError("cloudflared")
        self.proc = subprocess.Popen(
            [exe, "tunnel", "--no-autoupdate", "--protocol", "http2",
             "--url", "http://127.0.0.1:%d" % self.port],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            universal_newlines=True, bufsize=1)
        threading.Thread(target=self._read, daemon=True).start()
        if not self._ev.wait(timeout) or not self.url:
            err = self.tail[-1] if self.tail else "timeout"
            self.stop()
            raise RuntimeError("tunnel:" + err)
        return self.url

    def _read(self):
        for line in self.proc.stdout:
            line = line.strip()
            if line:
                self.tail = (self.tail + [line])[-5:]
            m = URL_RE.search(line)
            if m and m.group(1) != "api" and not self.url:
                self.url = m.group(0)
                self._ev.set()
        self._ev.set()

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
