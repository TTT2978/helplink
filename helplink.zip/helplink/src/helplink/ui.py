"""Terminal output helpers (kept minimal on purpose)."""
import os
import shutil
import sys
import textwrap

YES = {"y", "yes", "c", "co", "có", "ok", "oke", "dong y", "đồng ý"}


def _c(code, s):
    if sys.stdout.isatty() and not os.environ.get("NO_COLOR"):
        return "\033[%sm%s\033[0m" % (code, s)
    return s


def step(msg):
    print(_c("32", "[+]") + " " + msg, flush=True)


def note(msg):
    print(_c("36", "[*]") + " " + msg, flush=True)


def warn(msg):
    print(_c("33", "[!]") + " " + msg, flush=True)


def err(msg):
    print(_c("31", "[x]") + " " + msg, file=sys.stderr, flush=True)


def title(msg):
    print("\n" + _c("1", "== " + msg + " =="), flush=True)


def say(text):
    width = max(40, min(shutil.get_terminal_size((80, 20)).columns - 2, 92))
    for para in text.strip("\n").split("\n"):
        if not para.strip():
            print()
            continue
        indent = len(para) - len(para.lstrip())
        hang = indent + 3 if para.lstrip()[:2] in ("1)", "2)", "3)") else indent
        print(textwrap.fill(para, width=width, subsequent_indent=" " * hang))
    sys.stdout.flush()


def ask(prompt, default=""):
    suffix = " [%s]" % default if default != "" else ""
    try:
        v = input("%s%s: " % (prompt, suffix)).strip()
    except EOFError:
        v = ""
    return v or default


def confirm(prompt, default=False):
    try:
        v = input("%s %s: " % (prompt, "[Y/n]" if default else "[y/N]")).strip().lower()
    except EOFError:
        v = ""
    if not v:
        return default
    return v in YES
