"""Tiny translation helper. Strings live in lang/<code>.json (vi, en)."""
import json

from .paths import APP_DIR

LANGS = ("vi", "en")


def _load(code):
    try:
        with open(str(APP_DIR / "lang" / (code + ".json")), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


class I18n:
    def __init__(self, lang):
        self.lang = lang if lang in LANGS else "en"
        self._d = _load(self.lang)
        self._fb = _load("en")

    def __call__(self, key, **kw):
        s = self._d.get(key) or self._fb.get(key) or key
        try:
            return s.format(**kw)
        except (KeyError, IndexError, ValueError):
            return s

    def web(self):
        return {k[4:]: v for k, v in self._d.items() if k.startswith("web_")}
