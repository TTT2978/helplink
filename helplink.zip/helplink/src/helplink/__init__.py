"""HelpLink - consent-based remote help tool (web terminal over OpenSSH + cloudflared)."""
__version__ = "1.0.0"
