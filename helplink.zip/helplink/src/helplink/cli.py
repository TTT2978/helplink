import shutil
import sys

from . import __version__, shells, ui
from .i18n import I18n
from .paths import HOME, load_config

HELP = """HelpLink %s - consent-based remote help (web terminal over OpenSSH + cloudflared)

  helplink            start sharing (asks for consent first)
  helplink --setup    run the setup wizard again
  helplink --uninstall  remove aliases and ~/.helplink
  helplink --version
"""


def main(argv=None):
    if sys.version_info < (3, 7):
        print("[x] Python 3.7+ required / Cần Python 3.7+")
        return 1
    args = list(sys.argv[1:] if argv is None else argv)
    try:
        if "--version" in args:
            print(__version__)
            return 0
        if "-h" in args or "--help" in args:
            print(HELP % __version__)
            return 0
        if "--setup" in args:
            from . import wizard
            return wizard.run()
        cfg = load_config()
        tr = I18n(cfg["lang"])
        if "--uninstall" in args:
            if ui.confirm(tr("u_confirm", path=str(HOME)), False):
                shells.remove()
                shutil.rmtree(str(HOME), ignore_errors=True)
                ui.step(tr("u_done"))
            return 0
        if not cfg["configured"]:
            from . import wizard
            return wizard.run()
        from . import session
        return session.run(cfg, tr)
    except KeyboardInterrupt:
        print()
        return 130
