"""OpenSSH part: keys + a private sshd that listens ONLY on 127.0.0.1."""
import getpass
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

from .paths import KEY_DIR, RUN_DIR

SSHD_PATHS = ["/usr/sbin/sshd", "/usr/local/sbin/sshd", "/usr/bin/sshd",
              "/usr/local/bin/sshd", "/sbin/sshd", "/usr/lib/openssh/sshd"]


def find_sshd():
    p = shutil.which("sshd")
    if p:
        return os.path.abspath(p)
    prefix = os.environ.get("PREFIX")
    for c in ([prefix + "/bin/sshd"] if prefix else []) + SSHD_PATHS:
        if os.access(c, os.X_OK):
            return c
    return None


def have_client():
    return bool(shutil.which("ssh") and shutil.which("ssh-keygen"))


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _keygen(path, comment):
    if Path(path).exists():
        return
    subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", comment, "-f", str(path)],
                   check=True, stdin=subprocess.DEVNULL)


def ensure_keys(cfg):
    """Create the long-lived key pair (used by setup for 'keep' mode)."""
    if cfg.get("key_mode") == "keep":
        KEY_DIR.mkdir(parents=True, exist_ok=True)
        _keygen(KEY_DIR / "session_ed25519", "helplink-session")
    _keygen(KEY_DIR / "host_ed25519", "helplink-host")


class SshServer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.proc = None
        self.port = 0
        self.user = getpass.getuser()
        self.client_key = None
        self._fresh = []

    # -- preparation -------------------------------------------------
    def prepare(self):
        if not have_client():
            raise RuntimeError("ssh-client")
        self.sshd_bin = find_sshd()
        if not self.sshd_bin:
            raise RuntimeError("sshd")
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        KEY_DIR.mkdir(parents=True, exist_ok=True)
        mode = self.cfg.get("key_mode", "keep")
        if mode == "existing" and os.path.isfile(self.cfg.get("key_path", "")):
            self.client_key = Path(self.cfg["key_path"])
            pub = subprocess.run(["ssh-keygen", "-y", "-f", str(self.client_key)], check=True,
                                 stdout=subprocess.PIPE, stdin=subprocess.DEVNULL,
                                 universal_newlines=True).stdout.strip()
        else:
            if mode == "fresh":
                self.client_key = RUN_DIR / "session_ed25519"
                for p in (self.client_key, Path(str(self.client_key) + ".pub")):
                    if p.exists():
                        p.unlink()
                self._fresh = [self.client_key, Path(str(self.client_key) + ".pub")]
            else:
                self.client_key = KEY_DIR / "session_ed25519"
            _keygen(self.client_key, "helplink-session")
            pub = Path(str(self.client_key) + ".pub").read_text().strip()
        _keygen(KEY_DIR / "host_ed25519", "helplink-host")

        auth = RUN_DIR / "authorized_keys"
        auth.write_text(pub + "\n")
        os.chmod(str(auth), 0o600)

        self.port = free_port()
        if os.geteuid() == 0:
            os.makedirs("/run/sshd", exist_ok=True)
        cfg_text = "\n".join([
            "Port %d" % self.port,
            "ListenAddress 127.0.0.1",
            "HostKey %s" % (KEY_DIR / "host_ed25519"),
            "PidFile %s" % (RUN_DIR / "sshd.pid"),
            "AuthorizedKeysFile %s" % auth,
            "AuthenticationMethods publickey",
            "PubkeyAuthentication yes",
            "PasswordAuthentication no",
            "PermitRootLogin yes",
            "UsePAM no",
            "StrictModes no",
            "AllowTcpForwarding no",
            "X11Forwarding no",
            "PrintMotd no",
            "LogLevel ERROR",
            "",
        ])
        self.conf = RUN_DIR / "sshd_config"
        self.conf.write_text(cfg_text)

    # -- lifecycle -----------------------------------------------------
    def start(self):
        log = open(str(RUN_DIR / "sshd.log"), "w")
        self.proc = subprocess.Popen([self.sshd_bin, "-D", "-e", "-f", str(self.conf)],
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=log)
        deadline = time.time() + 8
        while time.time() < deadline:
            if self.proc.poll() is not None:
                break
            try:
                socket.create_connection(("127.0.0.1", self.port), timeout=0.5).close()
                return
            except OSError:
                time.sleep(0.2)
        tail = ""
        try:
            tail = (RUN_DIR / "sshd.log").read_text().strip().splitlines()[-1]
        except (OSError, IndexError):
            pass
        self.stop()
        raise RuntimeError("sshd-start:" + tail)

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def client_cmd(self):
        return ["ssh", "-tt", "-i", str(self.client_key), "-p", str(self.port),
                "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null", "-o", "PasswordAuthentication=no",
                "-o", "LogLevel=ERROR", "%s@127.0.0.1" % self.user]

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        for p in self._fresh:
            try:
                p.unlink()
            except OSError:
                pass
        try:
            (RUN_DIR / "authorized_keys").unlink()
        except OSError:
            pass
