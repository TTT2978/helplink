"""Web terminal: tiny HTTP + WebSocket server that bridges the browser to a PTY (ssh)."""
import fcntl
import hmac
import http.server
import json
import os
import pty
import signal
import socketserver
import struct
import termios
import threading
import time
from urllib.parse import parse_qs, urlparse

from .paths import APP_DIR
from .wsproto import WebSocket


class _Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def _write_all(fd, data):
    while data:
        n = os.write(fd, data)
        data = data[n:]


def _resize(fd, cols, rows):
    cols = max(1, min(cols, 500))
    rows = max(1, min(rows, 300))
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


def _reap(pid):
    try:
        os.kill(pid, signal.SIGHUP)
    except OSError:
        pass
    for _ in range(20):
        try:
            done, _s = os.waitpid(pid, os.WNOHANG)
        except OSError:
            return
        if done:
            return
        time.sleep(0.1)
    try:
        os.kill(pid, signal.SIGKILL)
        os.waitpid(pid, 0)
    except OSError:
        pass


class WebTerm:
    def __init__(self, token, cmd, labels, on_event=None):
        self.token = token
        self.cmd = cmd
        self.labels = labels
        self.on_event = on_event or (lambda kind, info: None)
        self.lock = threading.Lock()   # one helper at a time
        self.active = set()
        self.httpd = None
        self.port = 0

    # -- helpers -------------------------------------------------------
    def check(self, tok):
        return hmac.compare_digest(tok.encode(), self.token.encode())

    def page(self):
        html = (APP_DIR / "web" / "index.html").read_text(encoding="utf-8")
        data = json.dumps(self.labels, ensure_ascii=False).replace("</", "<\\/")
        return html.replace("<!--LABELS-->", "<script>window.__L=%s;</script>" % data).encode("utf-8")

    def start(self):
        ctx = self

        class Handler(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def _send(self, code, body, ctype="text/plain; charset=utf-8"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(body)
                self.close_connection = True

            def do_GET(self):
                u = urlparse(self.path)
                tok = parse_qs(u.query).get("t", [""])[0]
                if not ctx.check(tok):
                    time.sleep(0.5)           # slow down guessing
                    return self._send(403, b"forbidden")
                if u.path == "/ws":
                    return self._ws()
                if u.path in ("/", "/index.html"):
                    return self._send(200, ctx.page(), "text/html; charset=utf-8")
                return self._send(404, b"not found")

            def _ws(self):
                key = self.headers.get("Sec-WebSocket-Key")
                if self.headers.get("Upgrade", "").lower() != "websocket" or not key:
                    return self._send(400, b"bad request")
                if not ctx.lock.acquire(False):
                    return self._send(409, b"busy")
                ip = self.headers.get("CF-Connecting-IP") or self.client_address[0]
                try:
                    ws = WebSocket(self.rfile, self.connection)
                    ws.handshake(key)
                    self.close_connection = True
                    ctx.on_event("connected", ip)
                    ctx._bridge(ws)
                finally:
                    ctx.lock.release()
                    ctx.on_event("disconnected", ip)

        self.httpd = _Server(("127.0.0.1", 0), Handler)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return self.port

    # -- PTY bridge ----------------------------------------------------
    def _bridge(self, ws):
        pid, fd = pty.fork()
        if pid == 0:                                   # child -> ssh
            os.environ["TERM"] = "xterm-256color"
            try:
                os.execvp(self.cmd[0], self.cmd)
            except Exception:
                pass
            os._exit(127)
        self.active.add(pid)
        alive = threading.Event()
        alive.set()

        def pump():
            try:
                while alive.is_set():
                    data = os.read(fd, 65536)
                    if not data:
                        break
                    ws.send(2, data)
            except OSError:
                pass
            ws.close()

        def keepalive():
            while alive.is_set():
                time.sleep(25)
                try:
                    ws.send(9, b"")
                except OSError:
                    break

        threading.Thread(target=pump, daemon=True).start()
        threading.Thread(target=keepalive, daemon=True).start()
        try:
            while True:
                m = ws.recv()
                if m is None:
                    break
                op, data = m
                if op != 1:
                    continue
                try:
                    j = json.loads(data.decode("utf-8", "replace"))
                except ValueError:
                    continue
                kind = j.get("type")
                if kind == "input":
                    _write_all(fd, str(j.get("data", "")).encode("utf-8"))
                elif kind == "resize":
                    _resize(fd, int(j.get("cols", 80)), int(j.get("rows", 24)))
        except (EOFError, OSError, ValueError):
            pass
        finally:
            alive.clear()
            _reap(pid)
            self.active.discard(pid)
            try:
                os.close(fd)
            except OSError:
                pass
            ws.close()

    def stop(self):
        for pid in list(self.active):
            _reap(pid)
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
