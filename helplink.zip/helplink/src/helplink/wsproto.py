"""Minimal RFC 6455 WebSocket (server side, stdlib only)."""
import base64
import hashlib
import socket
import struct
import threading

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_FRAME = 1 << 20


class WebSocket:
    def __init__(self, rfile, sock):
        self.rfile = rfile
        self.sock = sock
        self._lock = threading.Lock()

    def handshake(self, key):
        accept = base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()
        self.sock.sendall(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n"
                           "Connection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n" % accept).encode())

    def _read(self, n):
        b = self.rfile.read(n)
        if not b or len(b) < n:
            raise EOFError
        return b

    def send(self, opcode, payload=b""):
        n = len(payload)
        if n < 126:
            head = struct.pack("!BB", 0x80 | opcode, n)
        elif n < 65536:
            head = struct.pack("!BBH", 0x80 | opcode, 126, n)
        else:
            head = struct.pack("!BBQ", 0x80 | opcode, 127, n)
        with self._lock:
            self.sock.sendall(head + payload)

    def recv(self):
        """Return (opcode, bytes) for text/binary messages, or None on close."""
        msg, first = b"", None
        while True:
            b1, b2 = self._read(2)
            fin, op, ln = b1 & 0x80, b1 & 0x0F, b2 & 0x7F
            if ln == 126:
                ln = struct.unpack("!H", self._read(2))[0]
            elif ln == 127:
                ln = struct.unpack("!Q", self._read(8))[0]
            if ln > MAX_FRAME:
                raise ValueError("frame too large")
            mask = self._read(4) if b2 & 0x80 else None
            data = self._read(ln) if ln else b""
            if mask:
                data = bytes(c ^ mask[i & 3] for i, c in enumerate(data))
            if op == 8:
                return None
            if op == 9:
                self.send(10, data)
                continue
            if op == 10:
                continue
            if op in (1, 2):
                first, msg = op, data
            elif op == 0:
                msg += data
            else:
                continue
            if fin:
                return first, msg

    def close(self):
        try:
            self.send(8, b"")
        except OSError:
            pass
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
