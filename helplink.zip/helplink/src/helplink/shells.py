"""Install / remove the alias in Bash, Zsh and Fish startup files."""
import shlex
import shutil
from pathlib import Path

BEGIN = "# >>> helplink >>>"
END = "# <<< helplink <<<"


def _targets():
    h = Path.home()
    cands = [("bash", h / ".bashrc"), ("zsh", h / ".zshrc"),
             ("fish", h / ".config" / "fish" / "config.fish")]
    out = [(n, p) for n, p in cands if shutil.which(n) or p.exists()]
    return out or [cands[0]]


def _block(shell, alias, launcher):
    cmd = "sh " + shlex.quote(str(launcher))
    if shell == "fish":
        body = "function %s\n    %s $argv\nend" % (alias, cmd)
    else:
        body = "alias %s=%s" % (alias, shlex.quote(cmd))
    return "%s\n%s\n%s\n" % (BEGIN, body, END)


def _strip(text):
    while BEGIN in text and END in text:
        a = text.index(BEGIN)
        b = text.index(END, a) + len(END)
        text = text[:a].rstrip("\n") + "\n" + text[b:].lstrip("\n")
    return text


def install(alias, launcher):
    done = []
    for shell, rc in _targets():
        rc.parent.mkdir(parents=True, exist_ok=True)
        old = rc.read_text(encoding="utf-8") if rc.exists() else ""
        old = _strip(old)
        sep = "" if (not old or old.endswith("\n\n")) else ("\n" if old.endswith("\n") else "\n\n")
        rc.write_text(old + sep + _block(shell, alias, launcher), encoding="utf-8")
        done.append(str(rc))
    return done


def remove():
    done = []
    for _shell, rc in _targets():
        if rc.exists():
            old = rc.read_text(encoding="utf-8")
            if BEGIN in old:
                rc.write_text(_strip(old), encoding="utf-8")
                done.append(str(rc))
    return done
