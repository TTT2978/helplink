"""Interactive setup: explains every choice in detail (vi / en)."""
import os
import re
import shutil

from . import shells, sshd, ui
from .i18n import I18n
from .paths import APP_DIR, KEY_DIR, ensure_dirs, load_config, save_config
from .tunnel import find_cloudflared


def choose_lang():
    env = os.environ.get("HELPLINK_LANG")
    if env in ("vi", "en"):
        return env
    print("Choose language / Chọn ngôn ngữ:\n  1) Tiếng Việt\n  2) English")
    return "en" if ui.ask("1/2", "1") == "2" else "vi"


def run():
    ensure_dirs()
    cfg = load_config()
    cfg["lang"] = choose_lang()
    tr = I18n(cfg["lang"])

    ui.title(tr("w_title"))
    ui.say(tr("w_about"))

    # 1. alias ---------------------------------------------------------
    ui.title(tr("w_alias_t"))
    ui.say(tr("w_alias_help"))
    while True:
        a = ui.ask(tr("w_alias_q"), cfg["alias"])
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,30}", a):
            ui.warn(tr("w_alias_bad"))
            continue
        if a != cfg["alias"] and shutil.which(a) and not ui.confirm(tr("w_alias_exists", name=a), False):
            continue
        break
    cfg["alias"] = a

    # 2. ssh key -------------------------------------------------------
    ui.title(tr("w_key_t"))
    ui.say(tr("w_key_help", keydir=str(KEY_DIR)))
    c = ui.ask(tr("w_key_q"), "1")
    cfg["key_mode"], cfg["key_path"] = "keep", ""
    if c == "2":
        cfg["key_mode"] = "fresh"
    elif c == "3":
        while True:
            p = os.path.expanduser(ui.ask(tr("w_key_path_q"), "~/.ssh/id_ed25519"))
            if os.path.isfile(p):
                cfg["key_mode"], cfg["key_path"] = "existing", p
                break
            ui.warn(tr("w_key_bad", path=p))
            if not ui.confirm(tr("w_key_retry"), True):
                break

    # 3. token ---------------------------------------------------------
    ui.title(tr("w_token_t"))
    ui.say(tr("w_token_help"))
    cfg["token_mode"], cfg["token"] = "random", ""
    if ui.ask(tr("w_token_q"), "1") == "2":
        while True:
            tok = ui.ask(tr("w_token_fixed_q"))
            if len(tok) >= 12 and re.fullmatch(r"[A-Za-z0-9_-]+", tok):
                cfg["token_mode"], cfg["token"] = "fixed", tok
                break
            ui.warn(tr("w_token_bad"))

    # 4. timeout -------------------------------------------------------
    ui.title(tr("w_timeout_t"))
    ui.say(tr("w_timeout_help"))
    while True:
        v = ui.ask(tr("w_timeout_q"), str(cfg["timeout_min"]))
        if v.isdigit() and 0 <= int(v) <= 1440:
            cfg["timeout_min"] = int(v)
            break
        ui.warn(tr("w_timeout_bad"))

    # tools ------------------------------------------------------------
    ui.title(tr("w_check_t"))
    tools = [("ssh / ssh-keygen", sshd.have_client()), ("sshd", bool(sshd.find_sshd())),
             ("cloudflared", bool(find_cloudflared())), ("python3", True)]
    for name, ok in tools:
        (ui.step if ok else ui.warn)(tr("w_found" if ok else "w_missing", name=name))
    if not all(ok for _n, ok in tools):
        ui.say(tr("w_missing_hint"))
    elif cfg["key_mode"] == "keep":
        try:
            sshd.ensure_keys(cfg)
            ui.step(tr("w_key_ready", path=str(KEY_DIR / "session_ed25519")))
        except Exception as e:                      # keys are also created on first run
            ui.warn(str(e))

    # alias ------------------------------------------------------------
    files = shells.install(cfg["alias"], APP_DIR / "bin" / "helplink")
    cfg["configured"] = True
    save_config(cfg)
    ui.title(tr("w_done_t"))
    ui.step(tr("w_alias_done", name=cfg["alias"], files=", ".join(files)))
    ui.say(tr("w_reload"))
    for f in files:
        print("   source %s" % f)
    ui.say(tr("w_done", name=cfg["alias"]))
    return 0
