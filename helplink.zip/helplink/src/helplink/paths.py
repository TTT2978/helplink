"""Where things live: app folder (read-only code) and state folder (~/.helplink)."""
import json
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[2]
HOME = Path(os.environ.get("HELPLINK_HOME") or (Path.home() / ".helplink"))
BIN_DIR = HOME / "bin"
KEY_DIR = HOME / "keys"
RUN_DIR = HOME / "run"
CONFIG_FILE = HOME / "config.json"

DEFAULTS = {
    "configured": False,
    "lang": "en",
    "alias": "helplink",
    "key_mode": "keep",      # keep | fresh | existing
    "key_path": "",
    "token_mode": "random",  # random | fixed
    "token": "",
    "timeout_min": 60,
}


def ensure_dirs():
    for d in (HOME, BIN_DIR, KEY_DIR, RUN_DIR):
        d.mkdir(parents=True, exist_ok=True)
    for d in (HOME, KEY_DIR, RUN_DIR):
        try:
            os.chmod(str(d), 0o700)
        except OSError:
            pass


def load_config():
    cfg = dict(DEFAULTS)
    try:
        with open(str(CONFIG_FILE), "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg):
    ensure_dirs()
    tmp = str(CONFIG_FILE) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, str(CONFIG_FILE))
